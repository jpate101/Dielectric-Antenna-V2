from flask import Blueprint

bp = Blueprint('mountingSystem', __name__)

from MudMasterUI.mountingSystem import routes