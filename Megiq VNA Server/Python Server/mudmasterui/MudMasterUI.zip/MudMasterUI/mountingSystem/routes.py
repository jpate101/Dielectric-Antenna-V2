"""
*******************************************************************************
@file   MudMasterUI.mountingSystem.routes.py
@author Scott Thomason
@date   02 Feb 2022
@brief  Routes for the main section of the app.

REFERENCE:

*******************************************************************************
    Functions
*******************************************************************************

*******************************************************************************
"""

""" Imports
*******************************************************************************
"""
import json
import time
import os

import numpy as np

from datetime import datetime
from flask import render_template, flash, redirect, url_for, request, send_from_directory, jsonify, make_response, abort, Blueprint, current_app, session

from MudMasterUI.mountingSystem import bp
from MudMasterUI import controller_mountingSystem

""" Defines
*******************************************************************************
"""


""" Routes
*******************************************************************************
"""
@bp.route('/mounting-system')
def mounting_system():
    """Renders the home page."""

    return render_template(
        'mountingSystem/mounting_system.html',
        title='Mounting System',
        year=datetime.now().year,
        showFooter = True,
        current_actuator_position = controller_mountingSystem.get_actuator_target(),
    )


@bp.route('/mounting-system/move', methods = ['GET'])
def move():
    move_distance = request.args.get('distance', 0, type=int)
    print(move_distance)
    new_position = controller_mountingSystem.move_actuator(move_distance)
    print('new_position', new_position)

    return jsonify({'current_position': new_position})


@bp.route('/mounting-system/set', methods = ['GET'])
def position_set():
    move_position = request.args.get('position', -1, type=int)
    print(move_position)
    if move_position != -1:
        new_position = controller_mountingSystem.set_actuator(move_position)
        print('new_position', new_position)
        return jsonify({'current_position': new_position})

    return jsonify({'current_position': controller_mountingSystem.get_actuator_target()})