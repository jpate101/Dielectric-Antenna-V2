class Config_Machine(object):
    CONFIG_MACHINE = {
        'machineNumber': 'MMX',
        'vnaServerProcessPath': r"C:\Users\s4357040\source\repos\MegiqVnaServer\bin\Release\net5.0\publish\MegiqVnaServer.exe",
        }