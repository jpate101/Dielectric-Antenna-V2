class Config_Machine(object):
    CONFIG_MACHINE = {
        'machineNumber': 'MMBOT',
        'vnaServerProcessPath': r'C:\Users\MMBOT\Desktop\Megiq VNA Server\MegiqVnaServer.exe',
        }
